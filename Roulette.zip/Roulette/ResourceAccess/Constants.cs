﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class Constants
    {
        public class StoredProcedures
        {
            //User
            public const string GetUserByEmail = "dbo.usp_GetUserByEmail";

            //Transaction
            public const string CreateTransaction = "dbo.usp_CreateTransaction";
            public const string GetTransactionByReference = "dbo.usp_GetTransactionByReference";

            //Spin
            public const string CreateSpin = "dbo.usp_CreateSpin";
            public const string GetSpins = "dbo.usp_GetSpins";

        }

        public class Parameters
        {           
            //User
            public const string Email = "@p_Email";

            //Transsction
            public const string TransactionType = "@p_TransactionType";
            public const string Amount = "@p_Amount";
            public const string Bet = "@p_Bet";
            public const string Reference = "@p_Reference";
            public const string CreatedDate = "@p_CreatedDate";

            //Spin
            public const string Number = "@p_Number";
            public const string Colour = "@p_Colour";
            public const string Parity = "@p_Parity";
            public const string BetRange = "@p_BetRange";
        }
    }
}
