﻿using Application.Common.Interfaces;
using Dapper;
using Infrastructure.BaseProvider;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class TransactionDataProvider : BaseDataProvider<TransactionDataProvider>, ITransactionDataProvider
    {
        public TransactionDataProvider(IConfiguration configuration, ILogger<TransactionDataProvider> logger) : base(configuration, logger)
        {
            
        }

        public async Task<string> CreateTransaction(Transaction transact)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.TransactionType, transact.TransactionType);
            dynamicParameters.Add(Constants.Parameters.Amount, transact.Amount);
            dynamicParameters.Add(Constants.Parameters.Bet, transact.Bet);
            dynamicParameters.Add(Constants.Parameters.Reference, transact.Reference);
            dynamicParameters.Add(Constants.Parameters.CreatedDate, transact.CreatedDate);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                return await conn.QueryFirstOrDefaultAsync<string>(
                       Constants.StoredProcedures.CreateTransaction, 
                       dynamicParameters, 
                       commandType: CommandType.StoredProcedure);
            });
        }

        public async Task<Transaction> GetTransaction(Guid reference)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Reference, reference);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                return await conn.QueryFirstOrDefaultAsync<Transaction>(
                       Constants.StoredProcedures.GetTransactionByReference,
                       dynamicParameters,
                       commandType: CommandType.StoredProcedure);
            });
        }
    }
}
