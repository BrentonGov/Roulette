﻿using Application.Common.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Roulette.Application.Common.Interfaces;
using Roulette.Infrastructure;

namespace Infrastructure
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services)
        {

            services.AddScoped<ITransactionDataProvider,TransactionDataProvider>();
            services.AddScoped<ISpinDataProvider, SpinDataProvider>();

            return services;
        }
    }

}
