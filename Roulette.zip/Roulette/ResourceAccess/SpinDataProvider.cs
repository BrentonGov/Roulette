﻿using Dapper;
using Infrastructure;
using Infrastructure.BaseProvider;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Roulette.Application.Common.Interfaces;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Infrastructure
{
    public class SpinDataProvider : BaseDataProvider<SpinDataProvider>, ISpinDataProvider
    {
        public SpinDataProvider(IConfiguration configuration, ILogger<SpinDataProvider> logger) : base(configuration, logger)
        {

        }
        public async Task CreateSpin(Spin spin)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Number, spin.Number);
            dynamicParameters.Add(Constants.Parameters.Colour, spin.Colour);
            dynamicParameters.Add(Constants.Parameters.Parity, spin.Parity);
            dynamicParameters.Add(Constants.Parameters.BetRange, spin.BetRange);
            dynamicParameters.Add(Constants.Parameters.CreatedDate, spin.CreatedDate);

            await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                return await conn.QueryFirstOrDefaultAsync(
                       Constants.StoredProcedures.CreateSpin,
                       dynamicParameters,
                       commandType: CommandType.StoredProcedure);
            });
        }

        public async Task<IEnumerable<Spin>> GetPreviousSpins()
        {           
            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                return await conn.QueryAsync<Spin>(
                       Constants.StoredProcedures.GetSpins,
                       commandType: CommandType.StoredProcedure);
            });
        }
    }
}
