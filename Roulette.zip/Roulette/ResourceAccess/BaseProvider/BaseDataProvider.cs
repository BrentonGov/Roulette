﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.BaseProvider
{
    public abstract class BaseDataProvider<Y>
        where Y : class
    {
        private ILogger<Y> _logger;
        private readonly string _connectionString;
        
        public BaseDataProvider(IConfiguration configuration, ILogger<Y> logger)
        {
            _connectionString = GetConnectionString(configuration);
            _logger = logger;
        }

        public async Task<T> ExecuteSQLAsync<T>(Func<SqlConnection, Task<T>> action)
        {
            try
            {
                using (var sqlconnection = new SqlConnection(_connectionString))
                {
                    await sqlconnection.OpenAsync();
                    return await action(sqlconnection);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError($"Could not execute SQL: Exception: {ex}");
                throw;
            }
        }

        public async Task ExecuteSQLAsync(Func<SqlConnection, Task> action)
        {
            await ExecuteSQLAsync(async (conn) =>
            {
                await action(conn);
                return true;
            });
        }

        protected string GetConnectionString(IConfiguration configuration)
        {
            try
            {
                return configuration["APIDatabase:Connection"];
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to build connection string. Exception: {ex}");
                throw;
            }
            
        }
    }
}
