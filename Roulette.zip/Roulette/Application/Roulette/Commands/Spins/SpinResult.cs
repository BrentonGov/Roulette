﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.Spins
{
    public class SpinResult
    {
        public int Number { get; set; }
        public string Colour { get; set; }
        public string Parity { get; set; }
        public string BetRange { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
