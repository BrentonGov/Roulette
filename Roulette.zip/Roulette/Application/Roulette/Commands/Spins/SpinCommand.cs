﻿using Application.Common.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Roulette.Application.Common.Constants;
using Roulette.Application.Common.Interfaces;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.Spins
{
    public record SpinCommand : IRequest<SpinResult>
    {
    }

    public class SpinCommandHandler : IRequestHandler<SpinCommand, SpinResult>
    {
        private ISpinUtility _spinUtility;
        
        public SpinCommandHandler(ISpinUtility spinUtility)
        {
            _spinUtility = spinUtility;
        }

        public async Task<SpinResult> Handle(SpinCommand request, CancellationToken cancellationToken)
        {
            return await _spinUtility.PerformSpin();           
        }
    }
}
