﻿using FluentValidation;
using Roulette.Application.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.PlaceBets
{
    public class PlaceBetCommandValidator : AbstractValidator<PlaceBetCommand>
    {
        BetOptions _betOptions = new BetOptions();
        int parsedBet = 0;
        public PlaceBetCommandValidator()
        {
            RuleFor(x => x.Amount).NotEmpty()
                .GreaterThan(0).WithMessage("Please enter a valid bet amount!");
            RuleFor(x => x).Must(y => CheckifDecimal(y.Amount) == true).WithMessage("Please enter a valid decimal amount!");

            RuleFor(x => x.Bet).NotEmpty();
            RuleFor(x => x).Must(y => _betOptions.Types.Contains(y.Bet.ToLower())).When(z => CheckifInteger(z.Bet) == false).WithMessage("Please enter one of the following values for a valid bet: 0-36, red, black, even, odd, low, high");
            RuleFor(x => x).Must(y => parsedBet >= _betOptions.MinBet && parsedBet <= _betOptions.MaxBet).When(z => CheckifInteger(z.Bet) == true).WithMessage("Please enter a number between 0 and 36 for a valid bet"); ;
        }

        public bool CheckifInteger(string bet)
        {
           var check = Int32.TryParse(bet, out int result);
           parsedBet = result;
           return check;
        }

        public bool CheckifDecimal(Decimal amt)
        {
            return Decimal.TryParse(amt.ToString(), out _);

        }
    }
}
