﻿using Application.Common.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Roulette.Application.Roulette.Commands.Payout;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.PlaceBets
{
    public record PlaceBetCommand : IRequest<string>
    {
        public decimal Amount { get; set; }
        public string Bet { get; set; }
    }

    public class PlaceBetCommandHandler : IRequestHandler<PlaceBetCommand, string>
    {
        private ILogger<PlaceBetCommandHandler> _logger;
        private ITransactionDataProvider _transactionDataProvider;

        public PlaceBetCommandHandler(ILogger<PlaceBetCommandHandler> logger, ITransactionDataProvider transactionDataProvider)
        {
            _logger = logger;
            _transactionDataProvider = transactionDataProvider;
        }

        public async Task<string> Handle(PlaceBetCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var transact = new Transaction()
                {
                    Bet = request.Bet,
                    Amount = request.Amount,
                    TransactionType = "PlaceBet",
                    Reference = Guid.NewGuid(),
                    CreatedDate = DateTime.Now
                };

                return await _transactionDataProvider.CreateTransaction(transact);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to perform placeBet operation. Exception: {ex}");
                throw;
            }
            
        }
    }
}
