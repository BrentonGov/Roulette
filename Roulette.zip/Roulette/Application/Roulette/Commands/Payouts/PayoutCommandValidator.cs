﻿using FluentValidation;
using Roulette.Application.Roulette.Commands.Payout;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.Payouts
{
    public class PayoutCommandValidator : AbstractValidator<PayoutCommand>
    {
        public PayoutCommandValidator()
        {
            RuleFor(x => x.Reference).NotEmpty();
        }
    }
}
