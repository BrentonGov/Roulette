﻿using Application.Common.Exceptions;
using Application.Common.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Roulette.Application.Common.Interfaces;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.Payout
{
    public record PayoutCommand : IRequest<PayoutResult>
    {
        public Guid Reference { get; set; }
    }

    public class PayoutCommandHandler : IRequestHandler<PayoutCommand, PayoutResult>
    {
        private ILogger<PayoutCommandHandler> _logger;
        private ITransactionDataProvider _transactionDataProvider;
        private ISpinUtility _spinUtility;

        public PayoutCommandHandler(ILogger<PayoutCommandHandler> logger, ITransactionDataProvider transactionDataProvider, ISpinUtility spinUtility)
        {
            _logger = logger;
            _transactionDataProvider = transactionDataProvider;
            _spinUtility = spinUtility;
        }

        public async Task<PayoutResult> Handle(PayoutCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var placedBet = await _transactionDataProvider.GetTransaction(request.Reference);

                if (placedBet is null)
                {
                    throw new BadRequestException($"No open bet found for {request.Reference}");
                }

                var newSpin = await _spinUtility.PerformSpin();
                var result =  await _spinUtility.ReturnBetResult(placedBet, newSpin);

                var transact = new Transaction()
                {
                    Bet = placedBet.Bet,
                    Amount = result.IsSuccess ? placedBet.Amount + (placedBet.Amount * result.PayoutRate) : 0,
                    TransactionType = "Payout",
                    Reference = placedBet.Reference,
                    CreatedDate = DateTime.Now
                };

                await _transactionDataProvider.CreateTransaction(transact);

                return new PayoutResult()
                {
                    BetWon = result.IsSuccess,
                    PaidOutAmount = transact.Amount,
                    Bet = placedBet,
                    Spin = newSpin
                };
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to perform payout operation. Exception: {ex}");
                throw;
            }           

        }
    }
}
