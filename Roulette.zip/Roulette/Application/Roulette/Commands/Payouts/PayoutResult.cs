﻿using Roulette.Application.Roulette.Commands.Spins;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Commands.Payout
{
    public class PayoutResult
    {
        public bool BetWon { get; set; }
        public decimal PaidOutAmount { get; set; }
        public Transaction Bet { get; set; }
        public SpinResult Spin { get; set; }
    }
}
