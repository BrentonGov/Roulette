﻿using MediatR;
using Microsoft.Extensions.Logging;
using Roulette.Application.Common.Interfaces;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Roulette.Queries.GetPreviousSpins
{
    public record GetPreviousSpinsQuery : IRequest<List<Spin>>
    {
    }

    public class GetPreviousSpinsQueryHandler : IRequestHandler<GetPreviousSpinsQuery, List<Spin>>
    {
        private ILogger<GetPreviousSpinsQueryHandler> _logger;
        private ISpinDataProvider _spinDataProvider;
        private ISpinUtility _spinUtility;
        public GetPreviousSpinsQueryHandler(ILogger<GetPreviousSpinsQueryHandler> logger, ISpinDataProvider spinDataProvider, ISpinUtility spinUtility)
        {
            _logger = logger;
            _spinDataProvider = spinDataProvider;
            _spinUtility = spinUtility;
        }

        public async Task<List<Spin>> Handle(GetPreviousSpinsQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _spinDataProvider.GetPreviousSpins();
                return result.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to retrieve previous spins. Exception: {ex}");
                throw;
            }
        }
    }
}
