﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Common.Constants
{
    public static class BetColours
    {
        public static string Red => "red";
        public static string Black => "black";
        public static string Green => "green";
    }
}
