﻿using Microsoft.Extensions.Logging;
using Roulette.Application.Common.Constants;
using Roulette.Application.Common.Interfaces;
using Roulette.Application.Roulette.Commands.Payout;
using Roulette.Application.Roulette.Commands.Payouts;
using Roulette.Application.Roulette.Commands.Spins;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Common.Utilities
{
    public class SpinUtility : ISpinUtility
    {
        private readonly BetOptions _BetOptions;
        private readonly ISpinDataProvider _spinDataProvider;
        private readonly ILogger<SpinUtility> _logger;

        public SpinUtility(ISpinDataProvider spinDataProvider, ILogger<SpinUtility> logger)
        {
            _BetOptions = new BetOptions();
            _spinDataProvider = spinDataProvider;
            _logger = logger;
        }

        public async Task<SpinResult> PerformSpin()
        {
            try
            {
                var options = new BetOptions();
                var rand = new Random();
                var RouletteNumber = rand.Next(options.MinBet, options.MaxBet);

                var spinCreate = new Spin
                {
                    Colour = await ReturnBetColour(RouletteNumber),
                    Number = RouletteNumber,
                    Parity = await ReturnBetParity(RouletteNumber),
                    BetRange = await ReturnBetRange(RouletteNumber),
                    CreatedDate = DateTime.Now
                };

                await _spinDataProvider.CreateSpin(spinCreate);


                return new SpinResult
                {
                    Colour = spinCreate.Colour,
                    Number = spinCreate.Number,
                    Parity = spinCreate.Parity,
                    BetRange = spinCreate.BetRange,
                    CreatedDate = spinCreate.CreatedDate,
                };
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to perform spin operation. Exception: {ex}");
                throw;
            }
        }

        public Task<string> ReturnBetColour(int rouletteNumber)
        {
            if (_BetOptions.NumbersBlack.Contains(rouletteNumber))
            {
                return Task.FromResult(BetColours.Black);
            }
            else if (_BetOptions.NumbersRed.Contains(rouletteNumber))
            {
                return Task.FromResult(BetColours.Red);
            }
            else
            {
                return Task.FromResult(BetColours.Green);
            }
        }
        public Task<string> ReturnBetParity(int rouletteNumber)
        {
            if (rouletteNumber % 2 == 0)
            {
                return Task.FromResult(BetParity.Even);
            }
            else
            {
                return Task.FromResult(BetParity.Odd);
            }
        }
        public Task<string> ReturnBetRange(int rouletteNumber)
        {
            if (rouletteNumber >= _BetOptions.MinBet && rouletteNumber <= _BetOptions.MidBet)
            {
                return Task.FromResult(BetRange.Low);
            }
            else
            {
                return Task.FromResult(BetRange.High);
            }
        }

        public Task<PayoutDTO> ReturnBetResult(Transaction betPlaced, SpinResult spin)
        {
            if (betPlaced.Bet == spin.Parity)
                return Task.FromResult(new PayoutDTO { IsSuccess = true, PayoutRate = PayoutRates.Parity });
            if (betPlaced.Bet == spin.Colour)
                return Task.FromResult(new PayoutDTO { IsSuccess = true, PayoutRate = PayoutRates.ColourRedBlack });
            if (betPlaced.Bet == spin.BetRange)
                return Task.FromResult(new  PayoutDTO { IsSuccess = true, PayoutRate = PayoutRates.Range });
            if (betPlaced.Bet == spin.Number.ToString())
            {
                return betPlaced.Bet == 0.ToString() ? Task.FromResult(new PayoutDTO { IsSuccess = true, PayoutRate = PayoutRates.ColurGreen }) : Task.FromResult(new PayoutDTO { IsSuccess = true, PayoutRate = PayoutRates.Number });
            }
            else
                return Task.FromResult(new PayoutDTO { IsSuccess = false, PayoutRate = PayoutRates.Default });
        }
    }
}
