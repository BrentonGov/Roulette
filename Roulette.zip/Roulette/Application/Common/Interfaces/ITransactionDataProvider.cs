﻿using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Interfaces
{
    public interface ITransactionDataProvider
    {
        Task<string> CreateTransaction(Transaction bet);
        Task<Transaction> GetTransaction(Guid reference);
    }
}
