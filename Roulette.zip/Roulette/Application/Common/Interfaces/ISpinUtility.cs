﻿using Roulette.Application.Roulette.Commands.Payouts;
using Roulette.Application.Roulette.Commands.Spins;
using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Common.Interfaces
{
    public interface ISpinUtility
    {
        Task<string> ReturnBetColour(int rouletteNumber);
        Task<string> ReturnBetParity(int rouletteNumber);
        Task<string> ReturnBetRange(int rouletteNumber);        
        Task<PayoutDTO> ReturnBetResult(Transaction betPlaced, SpinResult spin);
        Task<SpinResult> PerformSpin();
    }
}
