﻿using Roulette.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Application.Common.Interfaces
{
    public interface ISpinDataProvider
    {
        Task CreateSpin(Spin spin);
        Task<IEnumerable<Spin>> GetPreviousSpins();
    }
}
