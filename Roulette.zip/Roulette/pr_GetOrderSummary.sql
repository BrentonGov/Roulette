CREATE PROCEDURE pr_GetOrderSummary
(
 @StartDate datetime ,
 @EndDate datetime,
 @CustomerID nchar(5) = NULL,
 @EmployeeID int = NULL
 )

AS
BEGIN	
	SELECT CONCAT(Emp.TitleOfCourtesy,' ', Emp.FirstName, ' ', Emp.LastName) AS EmployeeFullName,
	Ship.CompanyName AS ShipperCompanyName, 
	Cust.CompanyName AS CustomerCompanyName,
	COUNT(ord.OrderID) as NumberOfOrders,
	ord.OrderDate as [Date],
	SUM(ord.Freight) as TotalFreightCost,
	COUNT(DISTINCT OrdDet.ProductID) as NumberOfDifferentProducts,
	SUM(OrdSub.Subtotal) as TotalOrderValue
	
	FROM Orders ord
	JOIN Employees Emp ON ord.EmployeeID = Emp.EmployeeID
	JOIN Customers Cust ON ord.CustomerID = Cust.CustomerID
	JOIN [Order Details] OrdDet ON ord.OrderID = OrdDet.OrderID
	JOIN [Order Subtotals] OrdSub ON ord.OrderID = OrdSub.OrderID
	JOIN Shippers Ship ON ord.ShipVia = Ship.ShipperID
	
	WHERE 
	ord.OrderDate BETWEEN @StartDate AND @EndDate
    AND ord.CustomerID = COALESCE(@CustomerID, ord.CustomerID)
	AND ord.EmployeeID = COALESCE(@EmployeeID, ord.EmployeeID) 
	
	GROUP BY
	ord.OrderDate,
	CONCAT(Emp.TitleOfCourtesy, ' ', Emp.FirstName, ' ', Emp.LastName),
	Cust.CompanyName,
	Ship.CompanyName
END
