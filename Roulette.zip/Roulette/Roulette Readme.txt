Assumptions/Comments
-Can only place 1 bet at a time, payout one bet a time


Enchancements TODO:
-create transaction type table, retrieve and store in cache
-separate tables for bets and payouts
-bring in user concept to tie bets to
-maintain balance for users
-allow for multiple bets to be placed and settled


TODO/Incomplete

-implement unit tests

##Please keep in mind not a lot of time has gone into the project due to work commitments.