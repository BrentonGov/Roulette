﻿using Microsoft.AspNetCore.Mvc;
using Roulette.API.Controllers.Base;
using Roulette.Application.Roulette.Commands.Payout;
using Roulette.Application.Roulette.Commands.PlaceBets;
using Roulette.Application.Roulette.Commands.Spins;
using Roulette.Application.Roulette.Queries.GetPreviousSpins;
using Roulette.Domain.Entities;

namespace Roulette.API.Controllers
{
    public class RouletteController : ApiControllerBase
    {
        [HttpPost("placebet")]
        public async Task<ActionResult<string>> PlaceBet(PlaceBetCommand command)
        {
            return await Mediator.Send(command);
        }

        [HttpPost("payout")]
        public async Task<ActionResult<PayoutResult>> Payout(PayoutCommand command)
        {
            return await Mediator.Send(command);
        }

        [HttpPost("spin")]
        public async Task<ActionResult<SpinResult>> Spin()
        {
            return await Mediator.Send(new SpinCommand());
        }

        [HttpGet("previous-10-spins")]
        public async Task<ActionResult<IList<Spin>>> PreviousSpins()
        {
            return await Mediator.Send(new GetPreviousSpinsQuery());
        }
    }
}
