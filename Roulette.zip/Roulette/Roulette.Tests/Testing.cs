﻿using Application.Common.Interfaces;
using Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using Respawn;
using Roulette.Application.Common.Interfaces;
using Roulette.Domain.Entities;
using Roulette.Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Roulette.Tests;

[SetUpFixture]
public partial class Testing
{
    private static WebApplicationFactory<Program> _factory = null!;
    private static IConfiguration _configuration = null!;
    private static IServiceScopeFactory _scopeFactory = null!;
    private static Checkpoint _checkpoint = null!;

    [OneTimeSetUp]
    public void RunBeforeAnyTests()
    {
        _factory = new CustomWebApplicationFactory();
        _scopeFactory = _factory.Services.GetRequiredService<IServiceScopeFactory>();
        _configuration = _factory.Services.GetRequiredService<IConfiguration>();

        _checkpoint = new Checkpoint();       
    }

    public static async Task<TResponse> SendAsync<TResponse>(IRequest<TResponse> request)
    {
        using var scope = _scopeFactory.CreateScope();

        var mediator = scope.ServiceProvider.GetRequiredService<ISender>();

        return await mediator.Send(request);
    }

    public static async Task<IEnumerable<Spin>> GetPreviousSpins()
    {
        using var scope = _scopeFactory.CreateScope();
        var dataprovider = scope.ServiceProvider.GetRequiredService<ISpinDataProvider>();

        return await dataprovider.GetPreviousSpins();

    }

    public static async Task ResetState()
    {
        await _checkpoint.Reset(_configuration["APIDatabase:Connection"]);

    }

    [OneTimeTearDown]
    public void RunAfterAnyTests()
    {
    }
}
