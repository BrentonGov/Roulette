﻿using FluentAssertions;
using NUnit.Framework;
using Roulette.Application.Roulette.Commands.Spins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Tests.Roulette.Commands
{
    using static Testing;
    public class SpinCommandTests : BaseTestFixture
    {
        [Test]
        public async Task ShouldCreateSpin()
        {            
            await SendAsync(new SpinCommand());
            await SendAsync(new SpinCommand());

            var result = await GetPreviousSpins();
            result.Should().HaveCountGreaterThan(1);
        }
    }
}
