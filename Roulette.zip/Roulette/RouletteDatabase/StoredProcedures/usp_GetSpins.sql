﻿CREATE PROCEDURE [dbo].[usp_GetSpins]
	
AS
SET XACT_ABORT, NOCOUNT ON

BEGIN

	SELECT TOP 10 *
	FROM dbo.[Spin]
	order by 1 desc

END