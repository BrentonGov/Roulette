﻿CREATE PROCEDURE [dbo].[usp_CreateTransaction]
	@p_TransactionType VARCHAR(50),
	@p_Amount DECIMAL(18,2),
	@p_Bet VARCHAR(50),
	@p_Reference VARCHAR(500),	
	@p_CreatedDate DATETIME

AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

		INSERT INTO [dbo].[Transaction]
		(
			[TransactionType],
			[Amount],
			[Bet],
			[Reference],
			[CreatedDate]
		)
		VALUES
		(
			@p_TransactionType,
			@p_Amount,
			@p_Bet,
			@p_Reference,
			@p_CreatedDate
		)

		SELECT @p_Reference
END
