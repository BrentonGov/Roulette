﻿CREATE PROCEDURE [dbo].[usp_GetTransactionByReference]
	@p_Reference uniqueidentifier 
AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

SELECT *
FROM  [dbo].[Transaction]
WHERE [dbo].[Transaction].[Reference] = @p_Reference
AND NOT EXISTS (SELECT [Id] from [dbo].[Transaction] 
				WHERE [dbo].[Transaction].[Reference] = @p_Reference 
				AND [dbo].[Transaction].[TransactionType] = 'Payout')

END
GO

