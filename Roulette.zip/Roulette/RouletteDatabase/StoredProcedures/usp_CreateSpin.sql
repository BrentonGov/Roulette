﻿CREATE PROCEDURE [dbo].[usp_CreateSpin]
	@p_Number INT,
	@p_Colour VARCHAR(50),
	@p_Parity VARCHAR(50),
	@p_BetRange VARCHAR(50),	
	@p_CreatedDate DATETIME

AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

		INSERT INTO [dbo].[Spin]
		(
			[Number],
			[Colour],
			[Parity],
			[BetRange],
			[CreatedDate]
		)
		VALUES
		(
			@p_Number,
			@p_Colour,
			@p_Parity,
			@p_BetRange,
			@p_CreatedDate
		)
		
END
