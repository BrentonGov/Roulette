﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roulette.Domain.Entities
{
    public class Transaction
    {
        public int? Id { get; set; }
        public string TransactionType { get; set; }
        public decimal Amount { get; set; }
        public string Bet { get; set; }
        public Guid Reference { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
